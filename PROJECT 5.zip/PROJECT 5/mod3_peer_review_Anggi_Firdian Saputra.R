# import vader package
library(vader)

#Number 3----
# find the scores
#Tweet A = 0.493
get_vader("The battery of the #Apple Macbook Pro 16 inch is so good that I can keep using it all night")

#Tweet B = -0.276
get_vader("$2400 for a base model? No thank you")

#Number 4----
#Tweet A = 0.493
get_vader("The battery of the #Apple Macbook Pro 16 inch is so good that I can keep using it all night")

#Tweet B = -0.276
get_vader("$2400 for a base model? No thank you")

#Number 5----
vscores <- c(0.000, -0.127, 0.241, 0.600, 0.250, 0.625, -0.237, 0.877, 0.800, 0.275)
mean(vscores) #0.3304

#Number 6----
"For example, the value of the mean is the correlation value of 10 product samples, because the mean value is greater than 0, then customer satisfaction is positive because it has a significant relationship or has a positive sentiment."

#Number 7----
# import vader package
library(vader)

# store vader scores to vscore
vscore = get_vader("Thanks @HomeDepot for this amazing grill!!")

# which score? = 0.807
as.numeric(vscore[2])

#Number 8----
vscore_neg = get_vader("It took me 2 hours to change my country setting in Google Play. What a mess!")

as.numeric(vscore_neg[2])




